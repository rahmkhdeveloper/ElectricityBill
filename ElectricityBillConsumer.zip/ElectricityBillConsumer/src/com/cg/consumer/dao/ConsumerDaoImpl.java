package com.cg.consumer.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.consumer.dto.ConsumerBean;
import com.cg.consumer.util.DBUtil;


public class ConsumerDaoImpl implements IConsumerDao{

	Connection con = null;
	
	@Override
	public int addDetails(ConsumerBean bean) {
		
		
		int result = 0;
		int value = 0;
		
		try {
			con = DBUtil.getConnection();
			String insertQuery = "INSERT INTO billdetails VALUES(customer_SEQ.nextval, ?, ?, ?)";
			PreparedStatement psi = con.prepareStatement(insertQuery);
			
			psi.setString(1, bean.getConsumerName());
			psi.setString(2, bean.getPhoneNumber());
			psi.setString(3, bean.getPassword());
			
			result = psi.executeUpdate();
			
			PreparedStatement ps1 = con.prepareStatement("SELECT customer_SEQ.currval FROM billdetails");
			ResultSet rs = ps1.executeQuery();
			
			while(rs.next()){
				value = rs.getInt(1);
			}
			
			//System.out.println(result+" rows inserted");
			System.out.println("Thank you");
			//logger.info("Executed successfully");
		
		} 
		catch (IOException|SQLException e) {
			e.printStackTrace();
			
		}


		return value;
	}
	
	
	
	@Override
	public ArrayList<ConsumerBean> retrieveDetails() {

		ArrayList<ConsumerBean> list = new ArrayList<ConsumerBean>();
		
		try {
			con = DBUtil.getConnection();
			
			String selectquery = "SELECT * FROM billdetails";
			
			//Statement stmt = con.createStatement();
			PreparedStatement pss = con.prepareStatement(selectquery);
			ResultSet rs = pss.executeQuery();
			
			while(rs.next()){
				
				int cid = rs.getInt(1);
				String consumerName = rs.getString(2);
				String phoneNumber= rs.getString(3);
				String password = rs.getString(4);
				
				ConsumerBean conObj = new ConsumerBean(cid, consumerName, phoneNumber, password);
				list.add(conObj);
			}
			
		} 
		
		catch (IOException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
		
	}
}
