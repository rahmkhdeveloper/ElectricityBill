package com.cg.consumer.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.consumer.dao.ConsumerDaoImpl;
import com.cg.consumer.dao.IConsumerDao;
import com.cg.consumer.dto.ConsumerBean;

public class ConsumerServiceImpl implements IConsumerService{

	IConsumerDao dao = null;
	@Override
	public int addDetails(ConsumerBean bean) {
		// TODO Auto-generated method stub
		dao = new ConsumerDaoImpl();
		return dao.addDetails(bean);
	}
	@Override
	public ArrayList<ConsumerBean> retrieveDetails() {
		// TODO Auto-generated method stub
		dao = new ConsumerDaoImpl();
		return dao.retrieveDetails();
	}
}
