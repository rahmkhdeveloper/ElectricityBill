package com.cg.controller.servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.consumer.dto.ConsumerBean;
import com.cg.consumer.service.ConsumerServiceImpl;
import com.cg.consumer.service.IConsumerService;

/**
 * Servlet implementation class HomeController
 */
@WebServlet("*.obj")
public class HomeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		ConsumerBean bean = new ConsumerBean();
		IConsumerService service = new ConsumerServiceImpl();
		HttpSession session = request.getSession();
		
		int finalAmount = 0;
		int res = 0;
		String target = null;
		
		String path = request.getServletPath();
		System.out.println(path);
		
		switch(path){
		
		case "/addDetails.obj":
			target = "NewConsumer.html";
			break;
			
			
		case "/retrieveDetails.obj":
			
			ArrayList<ConsumerBean> list = service.retrieveDetails();
			session.setAttribute("list", list);
			target = "retrieve.jsp";
			break;
			
			
		case "/details.obj":
				
				String consumerName = request.getParameter("consumerName");
				String phoneNumber = request.getParameter("phoneNumber");
				String password = request.getParameter("pwd");
				
				bean.setConsumerName(consumerName);
				bean.setPhoneNumber(phoneNumber);
				bean.setPassword(password);
				
				//bean = new ConsumerBean(consumerName, phoneNumber, password);
				res = service.addDetails(bean);
				
				
				session.setAttribute("seqid", res);
				
				System.out.println(res);

					target = "success.jsp";
				
				
			break;

		case "/page.obj":
			target = "calculate.jsp";
			break;
			
		case "/amount.obj":
			int amount = Integer.parseInt(request.getParameter("payAmount"));
			finalAmount = 1000 - amount;
			
			session.setAttribute("finalAmount", finalAmount);
			target = "amount.jsp";
			break;
		}
		
		
		RequestDispatcher rd = request.getRequestDispatcher(target);
		rd.forward(request, response);
		
	}

}
