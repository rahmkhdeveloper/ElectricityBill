package com.cg.consumer.dto;

public class ConsumerBean {

	
	//private int ConsumerNumber, payAmount;
	private int cid; 
	private String  ConsumerName, phoneNumber, password;
	

	
	public ConsumerBean(int cid, String consumerName, String phoneNumber,
			String password) {
		super();
		this.cid = cid;
		ConsumerName = consumerName;
		this.phoneNumber = phoneNumber;
		this.password = password;
	}

	public ConsumerBean(String consumerName, String phoneNumber, String password) {
		super();
		ConsumerName = consumerName;
		this.phoneNumber = phoneNumber;
		this.password = password;
	}
	
	public ConsumerBean(){}
	
	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getConsumerName() {
		return ConsumerName;
	}
	public void setConsumerName(String consumerName) {
		ConsumerName = consumerName;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	
	
}
