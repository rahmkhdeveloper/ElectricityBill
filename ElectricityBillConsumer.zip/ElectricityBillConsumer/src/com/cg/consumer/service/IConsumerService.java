package com.cg.consumer.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.consumer.dto.ConsumerBean;

public interface IConsumerService {

	int addDetails(ConsumerBean bean);
	ArrayList<ConsumerBean> retrieveDetails();
}
